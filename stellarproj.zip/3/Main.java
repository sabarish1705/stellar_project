import java.util.*;
import java.lang.Math;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int a=s.nextInt();
	    double b=((Math.sqrt(3))/4)*a*a;
	    System.out.printf("%.2f",b);
	}
}