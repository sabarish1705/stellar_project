import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner (System.in);
	    String str =s.next();
	    System.out.println("Hello " +str+ " !welcome to examly event management");
	}
}
