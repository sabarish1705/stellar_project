import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int a=s.nextInt();
		System.out.println((float)a);
		System.out.println((char)a);
	}
}
